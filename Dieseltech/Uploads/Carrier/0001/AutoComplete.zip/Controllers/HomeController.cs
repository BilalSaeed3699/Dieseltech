﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using AutocompleteMVC.Models;
namespace AutocompleteMVC.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        database_Access_Layer.db dblayer = new database_Access_Layer.db();
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetRecord(string prefix)
        {
            DataSet ds = dblayer.GetName(prefix);
            List<search> searchlist = new List<search>();
            foreach (DataRow  dr in ds.Tables[0].Rows)
            {
                searchlist.Add(new search {
                Name = dr["Name"].ToString(),
                Sr_no = dr["Sr_no"].ToString()
                });
            }
            return Json(searchlist, JsonRequestBehavior.AllowGet);
        }
    }
}
