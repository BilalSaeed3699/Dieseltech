﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutocompleteMVC.Models
{
    public class search
    {
        public string  Sr_no { get; set; }
        public string Name { get; set; }
    }
}